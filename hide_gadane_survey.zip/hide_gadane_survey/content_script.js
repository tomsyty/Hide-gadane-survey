window.addEventListener('load', () => {
  console.log('Załadowano skrypt hideGadaneSurvey');  
  const observer = new MutationObserver(mutations => {
    mutations.forEach(mutation => {
      if (mutation.type === 'childList') {
        mutation.addedNodes.forEach(addedNode => {
          if (addedNode.nodeName === 'DIV') {
            const popup = document.getElementsByClassName('lia-panel-dialog-modal-valuesurvey');
            const overlay = document.getElementsByClassName('ui-widget-overlay');
            const buttonNo = document.getElementsByClassName('lia-button lia-button-secondary decline-survey-link');
            if (popup.length) popup[0].style.display = 'none';
            if (overlay.length) overlay[0].style.display = 'none';
            if (buttonNo.length) {
              buttonNo[0].click();
              chrome.storage.local.get(['blockedCounter']).then(result => {
                result.blockedCounter++;
                chrome.storage.local.set({ blockedCounter: result.blockedCounter }).catch(error => {
                  console.log(`Błąd! Nie udało się zaktualizować licznika zablokowanych ankiet. Szczegóły (oryginalna treść wiadomości): ${error.message}`);
                });
              });
              console.log('zablokowano wyskakującą ankietę');
            }
          }
        }); 
      }
    });
  });
  observer.observe(document.body, {subtree: true, childList: true});
});