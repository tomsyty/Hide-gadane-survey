window.addEventListener('load', () => {
  chrome.storage.local.get(['blockedCounter']).then(result => {
    document.getElementById('counterSpan').innerText = result.blockedCounter;
  }).catch(() => {
    document.getElementById('counterSpan').innerText = '(błąd, nie udało się wczytać licznika zablokowanych ankiet)';
  });  
});