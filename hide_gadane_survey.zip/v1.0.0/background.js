chrome.runtime.onInstalled.addListener(details => {
	if (details.reason === 'install') {
		async function setDefaultValues() {
			await chrome.storage.local.set({
				blockedCounter: 0	
			});
		}	
		setDefaultValues().catch(error => {
			console.log(`Błąd! Podczas inicjalizacji domyślnych parametrów wystąpił błąd. Licznik zablokowanych ankiet nie będzie wyświetlany. Szczegóły błędu (oryginalna treść wiadomości): ${error.message}`);
		});
	}
});

(function main() {
  console.log('Załadowano rozszerzenie hideGadaneSurvey');
})();	

(async function checkUpdate() {
	let response;
	try {
		response = await fetch('https:/raw.githubusercontent.com/tomsyty/Hide-gadane-survey/main/current-version');
	} catch (error) {
		chrome.permissions.contains({ permissions: ['notifications'] }).then(granted => {
			if (granted) {
				chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
					if (buttonIndex === 0) {
						chrome.tabs.create({url: 'https://github.com/tomsyty/Hide-gadane-survey'});
					}
				});
				chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: ` Nie udało się sprawdzić aktualizacji rozszerzenia "${chrome.runtime.getManifest().name}". Sprawdź wersję ręcznie na stronie rozszerzenia.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true });
			} else {
				throw new Error(`Błąd! Nie udało się sprawdzić aktualizacji rozszerzenia "${chrome.runtime.getManifest().name}". Szczegóły (oryginalna treść błędu): ${error.message}`);
			}
		});
		return;
	}

	if (response.status === 200) {
		const currentVersion = await response.text();
		if (currentVersion.trim() !== chrome.runtime.getManifest().version) {
			chrome.permissions.contains({ permissions: ['notifications'] }).then(granted => {
				if (granted) {
					chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
						if (buttonIndex === 0) {
							chrome.tabs.create({url: 'https://github.com/tomsyty/Hide-gadane-survey'});
						}
					});
					chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: `Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true });
				}
			});
		}
	} else {
		console.log('brak pliku z informacją o aktualizacji');
	}
})();